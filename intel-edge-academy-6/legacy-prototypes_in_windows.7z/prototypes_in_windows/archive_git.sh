#!/usr/bin/bash
git archive --format=tar HEAD > ~/cTest.tar.gz